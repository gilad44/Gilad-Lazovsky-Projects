module.exports = {
  content: [
    './index.html',
    './scripts/**/*.js',
  ], theme: {
    extend: {},
  },
  plugins: [],
}