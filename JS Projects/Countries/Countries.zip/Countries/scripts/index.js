import { createCards } from "./domService.js";

createCards();